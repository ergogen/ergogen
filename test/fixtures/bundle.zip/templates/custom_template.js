module.exports = params => {
    return `Custom template override. The secret is ${params.custom.secret}.`
}